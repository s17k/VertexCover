#include <iostream>
using namespace std;
int main()
{
    int n, m, k;
    cin >> n >> m;
    for (int i=0; i<m; i++)
        cin >> k >> k;
    cin >> k;
    string pop, test;
    cin >> pop;
    int kkv, kke, tk;
    cin >> kkv >> kke >> tk >> test;
    cout << "Kernelizacja k^2: ";
    if (kkv==-1)
        cout << "NIE DOTYCZY\n";
    else if (kkv<=2*k*k && kke<=k*k)
        cout << "TAK\n";
    else
        cout << "NIE\n";
    cout << "Kernelizacja 3k: ";
    if (tk==-1)
        cout << "NIE DOTYCZY\n";
    else if (tk<=3*k)
        cout << "TAK\n";
    else
        cout << "NIE\n";
    cout << "Wynik: ";
    if (test==pop)
        cout << "POPRAWNY\n";
    else
        cout << "NIEPOPRAWNY\n";
}
